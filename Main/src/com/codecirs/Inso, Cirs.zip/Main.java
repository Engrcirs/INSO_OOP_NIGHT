package com.codecirs;

import java.util.Scanner;
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your last name: ");
        String lastName = scanner.nextLine();
        System.out.println("Enter your first name: ");
        String firstName = scanner.nextLine();

        System.out.println("Enter your age: ");
        int age = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Enter your gender: ");
        String gender =  scanner.nextLine();
        System.out.println("Enter your address: ");
        String address = scanner.nextLine();
        System.out.println("Enter your civil status: ");
        String civilStatus = scanner.nextLine();
        System.out.println("Enter the number of your brothers/sisters: ");
        String NumSiblings = scanner.nextLine();
//        print the result
        System.out.println("Full Name: " + lastName + ", " +  firstName);
        System.out.println("Age: " + age);
        System.out.println("Gender: " + gender);
        System.out.println("Address: " + address);
        System.out.println("Civil Status: " + civilStatus);
        System.out.println("# of brothers/sisters: " + NumSiblings);
        scanner.close();

    }
}